import Video from "@quarkly/community-kit/Video";
export default Video;