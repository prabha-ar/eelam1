export default {
	"pages": {
		"root": {
			"id": "root",
			"pageUrl": "root",
			"name": "root",
			"children": [
				"60e43f2c7c5362001af3ff9b",
				"60e43f2c7c5362001af3ff9d",
				"60e43fc3b42a9a0018930a1f"
			]
		},
		"60e43f2c7c5362001af3ff9b": {
			"id": "60e43f2c7c5362001af3ff9b",
			"name": "404",
			"pageUrl": "404"
		},
		"60e43f2c7c5362001af3ff9d": {
			"id": "60e43f2c7c5362001af3ff9d",
			"name": "index",
			"pageUrl": "index"
		},
		"60e43fc3b42a9a0018930a1f": {
			"id": "60e43fc3b42a9a0018930a1f",
			"pageUrl": "arivom-eelam",
			"name": "arivom eelam"
		}
	},
	"mode": "production",
	"projectType": "gatsby",
	"site": {
		"styles": {},
		"seo": {}
	}
}